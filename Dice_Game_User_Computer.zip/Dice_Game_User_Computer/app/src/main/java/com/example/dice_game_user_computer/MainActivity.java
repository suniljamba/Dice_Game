package com.example.dice_game_user_computer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView userDie, computerDie;
    Button higher, lower;

    TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDie = findViewById(R.id.user_die);
        computerDie = findViewById(R.id.computer_die);

        higher = findViewById(R.id.btnHigher);
        lower = findViewById(R.id.btnLower);

        resultView = findViewById(R.id.txtResult);

        int[] array_die = {R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};

        higher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int user_random_roll = random_die_rolle();
                int computer_random_roll = random_die_rolle();

                userDie.setImageResource(array_die[user_random_roll]);
                computerDie.setImageResource(array_die[computer_random_roll]);

                resultView.setText(wins_text(user_random_roll, computer_random_roll, "higher").toUpperCase());
            }
        });

        lower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int user_random_roll = random_die_rolle();
                int computer_random_roll = random_die_rolle();

                userDie.setImageResource(array_die[user_random_roll]);
                computerDie.setImageResource(array_die[computer_random_roll]);

                resultView.setText(wins_text(user_random_roll, computer_random_roll, "lower").toUpperCase());
            }
        });
    }

    public int random_die_rolle() {
        Random random_roll = new Random();
        return random_roll.nextInt(6);
    }

    public String wins_text ( int user , int computer, String inputText) {
        String resultText = "";
        if ( inputText.equals("higher")) { // Higher button is clicked
            if (user > computer) {
                resultText = "User wins!";
            } else if (user < computer) {
                resultText =  "Computer wins!";
            } else {
                resultText = "It’s a tie!";
            }
        } else { // Lower button  is clicked
            if (user < computer) {
                resultText = "User wins!";
            } else if (user > computer) {
                resultText =  "Computer wins!";
            } else {
                resultText = "It’s a tie!";
            }
        }
        return resultText;
    }
}